/*Defined in <dir.h>.*/
#define MXNAMLEN 255

#define UNIX42

#define PRIVATE static
#define PUBLIC
#define PROC void
#define FORWARD extern
#define IMPORTS extern
#define EXPORTS extern

#define EOS '\0'
typedef char * String;

#define ELIF else if
#define LOOP for(;;)
#define AND &&
#define OR ||
#define NOT !
#define ABS(dragon) ((dragon) >= 0 ? (dragon) : (-(dragon)))

