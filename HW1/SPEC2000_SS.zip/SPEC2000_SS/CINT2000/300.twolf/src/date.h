#define DATE "Mon Jan 25 18:50:36 EST 1988" 
