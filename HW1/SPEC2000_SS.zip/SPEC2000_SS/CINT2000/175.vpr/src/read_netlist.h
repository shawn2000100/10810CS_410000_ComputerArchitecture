void read_net (char *net_file);
void netlist_echo (char *foutput, char *net_file);
