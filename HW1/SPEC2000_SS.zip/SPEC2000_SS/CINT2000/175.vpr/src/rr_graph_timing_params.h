void add_rr_graph_C_from_switches (float ipin_cblock_C);
